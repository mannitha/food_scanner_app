{
    "name": "Nutrimann",
    "short_name": "Nutrimann",
    "start_url": ".",
    "display": "standalone",
    "background_color": "#ffffff",
    "theme_color": "#ffffff",
    "icons": [
      {
        "src": "favicon.png",
        "sizes": "512x512",
        "type": "image/png"
      }
    ]
  }
  